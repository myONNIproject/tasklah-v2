const mysql = require('mysql2/promise');

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { passport_id, email, referral_source } = body;

    if (!passport_id) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'passport_id is required' }),
      };
    }

    const connection = await mysql.createConnection(process.env.TIDB_CONNECTION_STRING);

    await connection.execute(
      `INSERT INTO genesis_passports (passport_id, email, referral_source, xp)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
       last_active = CURRENT_TIMESTAMP,
       email = COALESCE(VALUES(email), email)`,
      [passport_id, email || null, referral_source || null, 0]
    );

    await connection.end();

    return {
      statusCode: 201,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: true, passport_id }),
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: 'Failed to register passport' }),
    };
  }
};
